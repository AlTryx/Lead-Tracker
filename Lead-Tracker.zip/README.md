# Lead-Tracker
Chrome extension that saves up the links you type in.
